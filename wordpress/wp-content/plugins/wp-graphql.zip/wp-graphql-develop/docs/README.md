# WPGraphQL Docs
- **Repo:** The docs for WPGraphQL have been moved to a new repo: https://github.com/wp-graphql/docs.wpgraphql.com
- **Website:** The website for the docs is located at: https://docs.wpgraphql.com

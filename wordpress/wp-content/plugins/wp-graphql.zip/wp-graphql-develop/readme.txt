=== WPGraphQL ===
Contributors: jasonbahl, ryankanner, chopinbach, hughdevore
Tags: GraphQL, API, HTTP, Remote, Query Language
Requires at least: 4.7.0
Tested up to: 4.8.1
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

=== Description ===

Adds a GraphQL API to WordPress which can be used inside WordPress or from external sources via a "/graphql" HTTP endpoint.

The plugin is maintained on Github: https://github.com/wp-graphql/wp-graphql